/**
 * Appointment.java
 * 
 * Shelby Joiner
 * SNHU 
 * CS-320-19486-M01 Software Test, Automation QA 2025
 * Module Five Milestone
 * 
 * Represents an Appointment with a unique ID, date, and description.
 * Enforces constraints on each field:
 * - appointmentId: required, unique, max 10 characters, immutable.
 * - appointmentDate: required, cannot be null or in the past.
 * - description: required, max 50 characters.
 * 
 * Provides getter methods for all fields and setters for mutable fields 
 * with validation.
 */

import java.util.Date;

public class Appointment {
    // Unique, immutable appointment ID, max length 10 characters
    private final String appointmentId;

    // Appointment date, cannot be null or in the past
    private Date appointmentDate;

    // Description of the appointment, max length 50 characters
    private String description;

    /**
     * Constructs an Appointment object with specified ID, date, and description.
     * Validates inputs according to requirements.
     *
     * @param appointmentId Unique appointment ID (non-null, max 10 chars)
     * @param appointmentDate Appointment date (non-null, not in past)
     * @param description Description (non-null, max 50 chars)
     * @throws IllegalArgumentException if any argument is invalid
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be null or in the past");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    /**
     * Returns the unique appointment ID.
     *
     * @return appointmentId String
     */
    public String getAppointmentId() {
        return appointmentId;
    }

    /**
     * Returns the appointment date.
     *
     * @return appointmentDate Date
     */
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    /**
     * Sets the appointment date after validating it is not null or in the past.
     *
     * @param appointmentDate New appointment date
     * @throws IllegalArgumentException if appointmentDate is null or in the past
     */
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be null or in the past");
        }
        this.appointmentDate = appointmentDate;
    }

    /**
     * Returns the appointment description.
     *
     * @return description String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the appointment description after validating it is not null and within length limit.
     *
     * @param description New description string
     * @throws IllegalArgumentException if description is null or exceeds 50 characters
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
