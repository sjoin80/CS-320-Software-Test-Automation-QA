/**
 * AppointmentTest.java
 * 
 * Shelby Joiner
 * SNHU 
 * CS-320-19486-M01 Software Test, Automation QA 2025
 * Module Five Milestone
 * 
 * JUnit tests for the Appointment class.
 * Validates:
 * - Constructor constraints for ID, date, and description
 * - Setters with proper validation
 * - Immutability of appointmentId
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    /**
     * Utility method to get a date in the future.
     * 
     * @param daysAhead number of days ahead from today
     * @return Date object in the future
     */
    private Date getFutureDate(int daysAhead) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, daysAhead);
        return cal.getTime();
    }

    /**
     * Utility method to get a date in the past.
     * 
     * @param daysBefore number of days before today
     * @return Date object in the past
     */
    private Date getPastDate(int daysBefore) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -daysBefore);
        return cal.getTime();
    }

    /**
     * Test that a valid appointment can be created and accessed.
     */
    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("A001", futureDate, "Doctor appointment");
        assertEquals("A001", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Doctor appointment", appt.getDescription());
    }

    /**
     * Test invalid appointment ID constraints:
     * - Null ID
     * - ID longer than 10 characters
     */
    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = getFutureDate(1);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ABCDEFGHIJK", futureDate, "Desc"); // > 10 chars
        });
    }

    /**
     * Test invalid appointment dates:
     * - Null date
     * - Date in the past
     */
    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = getPastDate(1);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A002", pastDate, "Desc");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A003", null, "Desc");
        });
    }

    /**
     * Test invalid appointment descriptions:
     * - Null description
     * - Description over 50 characters
     */
    @Test
    public void testInvalidDescription() {
        Date futureDate = getFutureDate(1);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A004", futureDate, null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A005", futureDate, 
                "This description is definitely way too long to be valid because it exceeds fifty characters");
        });
    }

    /**
     * Test valid and invalid setting of appointmentDate.
     */
    @Test
    public void testSetAppointmentDate() {
        Date futureDate = getFutureDate(2);
        Date laterFutureDate = getFutureDate(5);
        Appointment appt = new Appointment("A006", futureDate, "Meeting");

        appt.setAppointmentDate(laterFutureDate);
        assertEquals(laterFutureDate, appt.getAppointmentDate());

        Date pastDate = getPastDate(1);
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate));
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(null));
    }

    /**
     * Test valid and invalid setting of description.
     */
    @Test
    public void testSetDescription() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("A007", futureDate, "Initial desc");

        appt.setDescription("Updated desc");
        assertEquals("Updated desc", appt.getDescription());

        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(
            "This description is definitely way too long to be valid because it exceeds fifty characters"));
    }

    /**
     * Test that appointment ID is immutable (no setter provided).
     */
    @Test
    public void testAppointmentIdNotUpdatable() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("A008", futureDate, "Test desc");

        // Validate that appointment ID is still as originally set
        assertEquals("A008", appt.getAppointmentId());
    }
}