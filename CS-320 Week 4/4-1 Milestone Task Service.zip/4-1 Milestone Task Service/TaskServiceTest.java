/*
 * ----------------------------------------------------------------------------
 * Name: Shelby Joiner
 * Class: CS-320-19486-M01 Software Test, Automation
 * Assignment: 4-1 Milestone: Task Service
 * File: TaskServiceTest.java
 * Description: Unit tests for the TaskService class, verifying add, delete,
 *              update, and error conditions using JUnit 5.
 * ----------------------------------------------------------------------------
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService service;

    // Initialize a fresh TaskService instance before each test
    @BeforeEach
    public void setup() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        service.addTask("1", "Name", "Description");
        assertNotNull(service.getTask("1"), "Task should be successfully added");
    }

    @Test
    public void testAddDuplicateTaskId() {
        service.addTask("1", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> service.addTask("1", "Another", "Another Desc"),
                     "Adding a duplicate task ID should throw an exception");
    }

    @Test
    public void testDeleteTask() {
        service.addTask("2", "To Delete", "Desc");
        service.deleteTask("2");
        assertNull(service.getTask("2"), "Task should be deleted and return null");
    }

    @Test
    public void testDeleteNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"),
                     "Deleting a nonexistent task should throw an exception");
    }

    @Test
    public void testUpdateName() {
        service.addTask("3", "Name", "Desc");
        service.updateTaskName("3", "New Name");
        assertEquals("New Name", service.getTask("3").getName(),
                     "Task name should be updated successfully");
    }

    @Test
    public void testUpdateDescription() {
        service.addTask("4", "Name", "Desc");
        service.updateTaskDescription("4", "New Desc");
        assertEquals("New Desc", service.getTask("4").getDescription(),
                     "Task description should be updated successfully");
    }

    @Test
    public void testUpdateNonexistentTask() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("999", "Doesn't Matter"),
                     "Updating name of nonexistent task should throw exception");
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescription("999", "Doesn't Matter"),
                     "Updating description of nonexistent task should throw exception");
    }
}
