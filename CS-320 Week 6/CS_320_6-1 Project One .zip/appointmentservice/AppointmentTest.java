/**
 * AppointmentTest.java
 * 
 * Shelby Joiner
 * SNHU 
 * CS-320-19486-M01 Software Test, Automation QA 2025
 * Module Five Milestone
 * 
 * JUnit tests for the Appointment class.
 * Validates:
 * - Constructor constraints for ID, date, and description
 * - Setters with proper validation
 * - Immutability of appointmentId
 */
package test.java.appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    /**
     * Utility method to get a date in the future relative to today.
     * 
     * @param daysAhead Number of days ahead from today
     * @return Date object in the future
     */
    private Date getFutureDate(int daysAhead) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, daysAhead);
        return cal.getTime();
    }

    /**
     * Utility method to get a date in the past relative to today.
     * 
     * @param daysBefore Number of days before today
     * @return Date object in the past
     */
    private Date getPastDate(int daysBefore) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -daysBefore);
        return cal.getTime();
    }

    /**
     * Test that a valid appointment can be created and its fields accessed correctly.
     */
    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("A001", futureDate, "Doctor appointment");
        assertEquals("A001", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Doctor appointment", appt.getDescription());
    }

    /**
     * Test invalid appointment ID constraints:
     * - Null ID
     * - ID longer than 10 characters
     */
    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = getFutureDate(1);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ABCDEFGHIJK", futureDate, "Desc")); // > 10 chars
    }

    /**
     * Test invalid appointment dates:
     * - Null date
     * - Date in the past
     */
    @Test
    public void testInvalidAppointmentDate() {
        Date pastDate = getPastDate(1);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A002", pastDate, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A003", null, "Desc"));
    }

    /**
     * Test invalid appointment descriptions:
     * - Null description
     * - Description exceeding 50 characters
     */
    @Test
    public void testInvalidDescription() {
        Date futureDate = getFutureDate(1);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A004", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A005", futureDate, 
            "This description is definitely way too long to be valid because it exceeds fifty characters"));
    }

    /**
     * Test valid and invalid setting of appointmentDate using setter method.
     */
    @Test
    public void testSetAppointmentDate() {
        Date futureDate = getFutureDate(2);
        Date laterFutureDate = getFutureDate(5);
        Appointment appt = new Appointment("A006", futureDate, "Meeting");

        // Valid update
        appt.setAppointmentDate(laterFutureDate);
        assertEquals(laterFutureDate, appt.getAppointmentDate());

        // Invalid updates
        Date pastDate = getPastDate(1);
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate));
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(null));
    }

    /**
     * Test valid and invalid setting of description using setter method.
     */
    @Test
    public void testSetDescription() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("A007", futureDate, "Initial desc");

        // Valid update
        appt.setDescription("Updated desc");
        assertEquals("Updated desc", appt.getDescription());

        // Invalid updates
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(
            "This description is definitely way too long to be valid because it exceeds fifty characters"));
    }

    /**
     * Test that appointment ID is immutable (no setter provided).
     * The original ID remains unchanged.
     */
    @Test
    public void testAppointmentIdNotUpdatable() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("A008", futureDate, "Test desc");

        assertEquals("A008", appt.getAppointmentId());
    }
}