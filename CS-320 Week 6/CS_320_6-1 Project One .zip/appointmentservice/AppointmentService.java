/**
 * AppointmentService.java
 * 
 * Shelby Joiner
 * SNHU 
 * CS-320-19486-M01 Software Test, Automation QA 2025
 * Module Five Milestone
 * 
 * Service class managing Appointment objects in-memory.
 * Provides functionality to add, delete, and retrieve appointments.
 * Enforces unique appointment IDs when adding appointments.
 */
package main.java.appointmentservice;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // In-memory storage for appointments keyed by unique appointment ID
    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds a new Appointment to the service.
     * Throws IllegalArgumentException if the appointment ID already exists.
     * 
     * @param appointment Appointment object to add
     * @throws IllegalArgumentException if duplicate appointment ID detected
     */
    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Deletes an existing Appointment by its appointment ID.
     * Throws IllegalArgumentException if no appointment found with the given ID.
     * 
     * @param appointmentId The ID of the appointment to delete
     * @throws IllegalArgumentException if appointment ID not found
     */
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointments.remove(appointmentId);
    }

    /**
     * Retrieves an Appointment by its appointment ID.
     * Returns null if the appointment does not exist.
     * 
     * @param appointmentId The ID of the appointment to retrieve
     * @return Appointment object or null if not found
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
