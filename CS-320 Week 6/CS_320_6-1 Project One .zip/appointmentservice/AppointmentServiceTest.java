/**
 * AppointmentServiceTest.java
 * 
 * Shelby Joiner
 * SNHU 
 * CS-320-19486-M01 Software Test, Automation QA 2025
 * Module Five Milestone
 * 
 * JUnit tests for the AppointmentService class.
 * Tests adding, retrieving, deleting appointments, 
 * and validates duplicate and nonexistent appointment handling.
 */
package test.java.appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.java.appointmentservice.AppointmentService;

import java.util.Date;
import java.util.Calendar;

public class AppointmentServiceTest {

    private AppointmentService service;

    /**
     * Utility method to generate a Date object daysAhead in the future.
     * 
     * @param daysAhead number of days ahead of the current date
     * @return Date object representing the future date
     */
    private Date getFutureDate(int daysAhead) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, daysAhead);
        return cal.getTime();
    }

    /**
     * Setup method to instantiate a fresh AppointmentService before each test.
     */
    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
    }

    /**
     * Tests adding a valid appointment and retrieving it by ID.
     */
    @Test
    public void testAddAndGetAppointment() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("AP001", futureDate, "Dental cleaning");
        service.addAppointment(appt);
        assertEquals("Dental cleaning", service.getAppointment("AP001").getDescription());
    }

    /**
     * Tests that adding an appointment with a duplicate ID throws an exception.
     */
    @Test
    public void testAddDuplicateAppointmentId() {
        Date futureDate = getFutureDate(1);
        Appointment appt1 = new Appointment("AP002", futureDate, "Meeting");
        Appointment appt2 = new Appointment("AP002", futureDate, "Conference");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    /**
     * Tests deleting an existing appointment successfully removes it.
     */
    @Test
    public void testDeleteAppointment() {
        Date futureDate = getFutureDate(1);
        Appointment appt = new Appointment("AP003", futureDate, "Lunch");
        service.addAppointment(appt);
        service.deleteAppointment("AP003");
        assertNull(service.getAppointment("AP003"));
    }

    /**
     * Tests that deleting a non-existent appointment throws an exception.
     */
    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NONEXIST"));
    }
}

