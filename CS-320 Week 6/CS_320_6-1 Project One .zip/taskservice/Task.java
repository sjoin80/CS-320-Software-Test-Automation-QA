/*
 * ----------------------------------------------------------------------------
 * Name: Shelby Joiner
 * Class: CS-320-19486-M01 Software Test, Automation
 * Assignment: 4-1 Milestone: Task Service
 * File: Task.java
 * Description: Represents an individual task with validation rules applied
 *              to its properties (ID, name, and description).
 * ----------------------------------------------------------------------------
 */
package main.java.taskservice;

public class Task {
    // Unique, immutable task identifier (max 10 characters, non-null)
    private final String taskId;

    // Name of the task (max 20 characters, non-null)
    private String name;

    // Description of the task (max 50 characters, non-null)
    private String description;

    /**
     * Constructor to create a new Task object with validation for all fields.
     *
     * @param taskId       Unique identifier for the task (max 10 characters)
     * @param name         Name of the task (max 20 characters)
     * @param description  Description of the task (max 50 characters)
     * @throws IllegalArgumentException if any input is null or exceeds limits
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    /**
     * Returns the unique task ID.
     *
     * @return taskId
     */
    public String getTaskId() {
        return taskId;
    }

    /**
     * Returns the task name.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the task name after validation.
     *
     * @param name New name for the task (max 20 characters)
     * @throws IllegalArgumentException if name is null or exceeds length
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    /**
     * Returns the task description.
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Updates the task description after validation.
     *
     * @param description New description (max 50 characters)
     * @throws IllegalArgumentException if description is null or exceeds length
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
