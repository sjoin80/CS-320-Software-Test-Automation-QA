/*
 * ----------------------------------------------------------------------------
 * Name: Shelby Joiner
 * Class: CS-320-19486-M01 Software Test, Automation
 * Assignment: 4-1 Milestone: Task Service
 * File: TaskService.java
 * Description: Provides operations to manage tasks including add, delete,
 *              and update, using in-memory storage.
 * ----------------------------------------------------------------------------
 */
package main.java.taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    // In-memory store for tasks keyed by their unique ID
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a new task to the service after validating uniqueness of the task ID.
     *
     * @param id          Unique task ID
     * @param name        Task name
     * @param description Task description
     * @throws IllegalArgumentException if task ID already exists or validation fails
     */
    public void addTask(String id, String name, String description) {
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        Task task = new Task(id, name, description);
        tasks.put(id, task);
    }

    /**
     * Deletes a task based on its ID.
     *
     * @param id Task ID to be removed
     * @throws IllegalArgumentException if the task ID is not found
     */
    public void deleteTask(String id) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(id);
    }

    /**
     * Updates the name of an existing task.
     *
     * @param id      Task ID of the task to update
     * @param newName New name for the task
     * @throws IllegalArgumentException if task ID is not found or name is invalid
     */
    public void updateTaskName(String id, String newName) {
        Task task = tasks.get(id);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setName(newName);
    }

    /**
     * Updates the description of an existing task.
     *
     * @param id             Task ID of the task to update
     * @param newDescription New description for the task
     * @throws IllegalArgumentException if task ID is not found or description is invalid
     */
    public void updateTaskDescription(String id, String newDescription) {
        Task task = tasks.get(id);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setDescription(newDescription);
    }

    /**
     * Retrieves a task by its ID.
     *
     * @param id Task ID to retrieve
     * @return Task object if found, or null if not found
     */
    public Task getTask(String id) {
        return tasks.get(id);
    }
}
