/*
 * ----------------------------------------------------------------------------
 * Name: Shelby Joiner
 * Class: CS-320-19486-M01 Software Test, Automation
 * Assignment: 4-1 Milestone: Task Service
 * File: TaskTest.java
 * Description: Unit tests for the Task class, verifying constructor validations,
 *              getters, and setters using JUnit 5.
 * ----------------------------------------------------------------------------
 */
package test.java.tasks;

import org.junit.jupiter.api.Test;

import main.java.taskservice.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    // Test valid Task object creation with valid inputs
    @Test
    public void testValidTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a test description");
        assertEquals("12345", task.getTaskId(), "Task ID should match the provided value");
        assertEquals("Test Task", task.getName(), "Task name should match the provided value");
        assertEquals("This is a test description", task.getDescription(), "Task description should match the provided value");
    }

    // Test constructor rejects invalid task IDs (null or too long)
    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Description"), "Null task ID should throw exception");
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Description"), "Task ID longer than 10 chars should throw exception");
    }

    // Test constructor rejects invalid names (null or too long)
    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Description"), "Null name should throw exception");
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "TooLongNameMoreThanTwentyChars", "Description"), "Name longer than 20 chars should throw exception");
    }

    // Test constructor rejects invalid descriptions (null or too long)
    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null), "Null description should throw exception");
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", "This description is definitely more than fifty characters long and should fail"), "Description longer than 50 chars should throw exception");
    }

    // Test setters for name and description with valid updates
    @Test
    public void testSetters() {
        Task task = new Task("1", "Initial", "Initial desc");
        task.setName("Updated Name");
        task.setDescription("Updated Description");
        assertEquals("Updated Name", task.getName(), "Name should be updated correctly");
        assertEquals("Updated Description", task.getDescription(), "Description should be updated correctly");
    }
}
